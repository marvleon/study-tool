//Marvin Leon Program 5 CS163

//This file contains the implementation of the graph class ADT.

#include "graph.h"


//Constructor
graph::graph(int size)
{
	list_size = size;
	adj_list = new vertex[size];
	flag = new int[size];
	//adj_list[i] is a vertex object
	//every vertext object has a topic and
	//a head pointer to a edge list

	for(int i = 0; i < size; ++i)
	{
		adj_list[i].head = nullptr;
		adj_list[i].topic = nullptr;
		flag[i] = 0;	
	}
} 



//Destructor
graph::~graph(void)
{
	for(int i = 0; i < list_size; ++i)
	{
		if(adj_list[i].head)
		{
			remove_edge(adj_list[i].head);	
		}
		if(adj_list[i].topic)
		{
			delete adj_list[i].topic;
			adj_list[i].topic = nullptr;
		}
	} 
	delete [] adj_list;	
	delete [] flag;
	list_size = 0;
}  



void graph::remove_edge(node * &head)
{
	if(!head)
		return;
	remove_edge(head -> next);
	delete head;
}



int graph::load_file(char * file_name)
{
	course_topic a_topic;	
	int count = 0; 
	char name[50];
	char notes[300];
	
	ifstream file_in;
	
	file_in.open(file_name);
	
	if(file_in)
	{
		file_in.get(name, 50, ':');
		file_in.ignore(100, ':');

		while(file_in && !file_in.eof())
		{		
			file_in.get(notes, 300, ':');
			file_in.ignore(100, ':');
	
			a_topic.create_topic(name, notes);
			insert_vertex(a_topic);	
			++count;	

			file_in.get(name, 50, ':');
			file_in.ignore(100, ':');
		}	
		file_in.close();
	}

	return count;
}


int graph::insert_vertex(course_topic & to_add)
{
	int i = 0;
	while(adj_list[i].topic && i < list_size)
		++i;
	
	if(i < list_size)
	{
		adj_list[i].topic = new course_topic;
		adj_list[i].topic -> copy_topic(to_add);
		return 1;	
	} 

	return 0;


}



int graph::insert_edge(char * current_vertex, char * to_attach)
{
	int index_current = find_index(current_vertex);
	int index_attach = find_index(to_attach);
	
	//head pointer is now looking at a new node
	adj_list[index_current].head = new node;
	adj_list[index_current].head -> adjacent = &adj_list[index_attach]; 
	adj_list[index_current].head -> next = nullptr;
	return 0;
} 


//Searches the graph for the vertex that matches the given key (name)
//Returns the location (index) of the found vertex
int graph::find_index(char * key)
{
	int i = 0;
	
	while(i < list_size && adj_list[i].topic && adj_list[i].topic -> compare(key))
		++i;
	
	if(i < list_size)
		return i;
	
	return 0;

}  



int graph::display_all() 
{
	for(int i = 0; i < list_size; ++i)
	{
		if(adj_list[i].topic)
		{
			adj_list[i].topic -> display();
		}
	} 
	
	return 1;
}   


int graph::display_list()
{
	for(int i = 0; i < list_size; ++i)
	{
		if(adj_list[i].topic)
		{
			adj_list[i].topic -> display();
			if(adj_list[i].head)
			{
				node * current = adj_list[i].head;	
				cout << "\tConnected to:\n\t";
				while(current)
				{
					current -> adjacent -> topic -> display_name();		
					current = current -> next;	
				}
			}	
		}
	} 
	return 0;
} 



int graph::display_adjacent(char * key) 
{
	int i = find_index(key);
	
	if(adj_list[i].head)
	{
		node * current = adj_list[i].head;	
		while(current)	
		{
			current -> adjacent -> topic -> display_name();		
			current = current -> next;	
		}
		return 1;
	} 
	
	return 0;
} 



