//Marvin Leon Program 5 CS163 

//This file contains the class interface for a course topic ADT.
//A course topic object contains private data types that represent
//the topics name and notes about the topic. The public functions
//include creating, copying, comparing, retrieving topic(s).

#ifndef TOPIC
#define TOPIC
class course_topic
{
	public: 
		course_topic(void);
		course_topic(void);
		int create_topic(char * name, char * notes);
		int copy_entry(course_topic & a_topic);
		int retrieve(char * name, course_topic & found);	
		int compare(char * compared_name);	
	private:
		char * name;
		char * notes;
}; 
#endif
